import React from "react";
import Image, { StaticImageData } from "next/image";
import Link from "next/link";

import Expertise1 from "../../assets/images/expertise-img-1.webp";
import Expertise2 from "../../assets/images/expertise-img-2.webp";
import Expertise3 from "../../assets/images/expertise-img-3.webp";
import Expertise4 from "../../assets/images/expertise-img-4.webp";
import Expertise5 from "../../assets/images/expertise-img-5.webp";
import Expertise6 from "../../assets/images/expertise-img-6.webp";




const Expertise: React.FC = () => {
  const expertiseItems: any = [
    {
      title: "Real Estate",
      img: Expertise1,
      desc: "SEO-driven websites for realtors, brokers, and property managers to attract buyers, sellers, and investors effortlessly.",
      link: "/proposal",
    },
    {
      title: "Financial Services",
      img: Expertise2,
      desc: "Custom web solutions for insurance agencies, notaries, and financial institutions to enhance credibility and client acquisition.",
      link: "/proposal",
    },
    {
      title: "Medical & Healthcare",
      img: Expertise3,
      desc: "HIPAA-compliant, fast, and SEO-friendly websites for clinics, hospitals, and healthcare providers to improve patient engagement.",
      link: "/proposal",
    },
    {
      title: "Small Businesses",
      img: Expertise4,
      desc: "Affordable, high-performing websites designed to help small businesses grow, attract customers, and increase online visibility.",
      link: "/proposal",
    },
    {
      title: "Automotive",
      img: Expertise5,
      desc: "Custom automotive websites with SEO and e-commerce features to help dealerships, repair shops, and auto parts businesses thrive.",
      link: "/proposal",
    },
    {
      title: "Professional Service",
      img: Expertise6,
      desc: "Sleek, conversion-focused websites for lawyers, consultants, and agencies to showcase expertise and attract more clients.",
      link: "/proposal",
    },
  ];

  return (
    <div className="expertise-service sp pb-0 p-0" id="expertise-service">
      <div className="container">
        <div className="row mb-4 mb-md-5">
          <div className="col-lg-12 text-center">
            <div className="heading-title pt-16">
              <h2>
                Our Digital Expertise Across
                <span> Industries </span>
              </h2>
            </div>
          </div>
        </div>
      </div>

   
      <div className="portfolio-sec-images solutions-list-images h-auto expertise-list-images ">
        <div className="row g-0 m-0 p-0">
          {expertiseItems.map((item: any, index: any) => (
            <div className="col-lg-4 col-md-6 p-0 m-0" key={index}>
              <div className="portfolio-list m-0 p-0">
                <div className="image image-anime reveal m-0 p-0 leading-none">
                  <Link href={item.link} className="block m-0 p-0 leading-none">
                    <Image
                      src={item.img}
                      alt={item.title}
                      className="block w-full h-auto m-0 p-0"
                    />
                  </Link>

                  <div className="solutions-hover-box">
                    <h3>{item.title}</h3>

                    <div className="solution-hover">
                      <p style={{ color: "white" }}>{item.desc}</p>
                      <Link href={item.link}>
                        Request A Quote
                        <i className="fa-solid fa-arrow-right"></i>
                      </Link>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default Expertise;

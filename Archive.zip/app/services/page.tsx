

import { GetPageData } from "@/lib/getdata";
import Link from "next/link";
import ServiceContact from "./[slug]/ServiceContact";
import Workslider from "./[slug]/Workslider";
import { BASE_URL } from "@/lib/url";
import { cache } from "react";
import { Metadata } from "next";
import { buildMetadata, getSchemaFromPageData, getSeoFromPageData } from "@/lib/seo";
import { notFound } from "next/navigation";
import StructuredData from "@/components/server/StructuredData";




const getPageData = cache(async () => {
  
  const data = await GetPageData("services", "page");
  return data?.page ?? data;
});

export async function generateMetadata(): Promise<Metadata> {
  const pageData = await getPageData();
  const seo = getSeoFromPageData(pageData);

  return buildMetadata(seo);
}


const Services = async () => {


    const pageData = await getPageData();
      const schemaData = getSchemaFromPageData(pageData);
     
    
    
      if (!pageData) notFound();
    





 
    return (
        <main className="page_content services-design-page">
            {/* HERO */}
            <StructuredData data={schemaData} />
            <div
                className="seo-landing-wrap"
                style={{
                    backgroundImage: `url(${pageData?.acf?.data?.banner_image})`,
                }}
            >
                <div className="container">
                    <div className="banner-caption">
                        <h1>{pageData?.acf?.data?.banner_heading}</h1>
                        <div
                            dangerouslySetInnerHTML={{
                                __html: pageData?.acf?.data?.banner_description,
                            }}
                        />
                        <Link className="btn btn-orange"
                            style={{ marginTop: "20px" }}
                            href="/proposal"

                        >
                            <span className="btn_label_1">Get My Free Proposal</span>
                            <span className="btn_icon">
                                <i className="fa-solid fa-arrow-right"></i>
                            </span>
                        </Link>
                    </div>
                </div>
            </div>

            {/* SERVICES */}
            <div className="related-post py-5">
                <div className="container">
                    <div className="row gy-4">
                        {pageData?.acf?.data?.services_page_section_3_card?.map(
                            (service: any, i: any) => (
                                <div className="col-lg-4 col-sm-6" key={i}>
                                    <div className="Servicecard">
                                        <img
                                            src={service.image}
                                            alt={service.title}
                                            className="serviceImages"
                                        />
                                        <div className="card-body">
                                            <h4>{service.title}</h4>
                                            <div
                                                dangerouslySetInnerHTML={{
                                                    __html: service?.description,
                                                }}
                                            />
                                        </div>
                                    </div>
                                </div>
                            )
                        )}
                    </div>
                </div>
            </div>

            {/* OUR WORK */}

            <Workslider pageData={pageData} />


            <div className="our-work-section  lazyloaded">
                <div className="container">
                    <div className="heading-blocks text-center mb-5">
                        <h2 className="sec-heading">
                            {pageData?.acf?.data?.service_page_section_6_title}
                        </h2>
                        <p>
                            We are immensely grateful for our clients’ kind words. Here is
                            what they want to say about our overall services.
                        </p>
                    </div>

                    <div className="servicetestimonial">
                        {pageData?.acf?.data?.service_page_section_6_testimonial?.map(
                            (item: any, index: any) => (
                                <div className="item clientTesticard " key={index}>
                                    <div className="border-testi">
                                        <div className="testimonial-wrapper lazyloaded">
                                            <div className="quote-icon">
                                                <img
                                                    src={`${BASE_URL}/wp-content/themes/perfecti/assets/seo-assets/images/tetimonial-quote-icon.png`}
                                                    alt="quotes"
                                                />
                                            </div>
                                            <span>
                                                {item?.post_content}
                                                <Link
                                                    href="/"
                                                    className="ms-1" style={{ color: "#FF4F02" }}>
                                                    Read More
                                                </Link>
                                            </span>
                                            <div
                                                className="testi-icon-wrap"
                                                style={{ paddingTop: "50px" }}
                                            >
                                                <div className="testi-icon">
                                                    {" "}
                                                    <img src={item?.featured_image?.url} />
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            )
                        )}
                    </div>
                </div>
            </div>

            <div className="our-work Challenges outerwrap related-post related-post-1 py-3 py-sm-5 mt-1 mt-sm-5">
                <div className="our-work-section  lazyloaded">
                    <div className="container">
                        <div className="heading-blocks text-center mb-5">
                            <h2 className="sec-heading">
                                {pageData?.acf?.data?.service_page_section_7_title}
                            </h2>
                            <p>{pageData?.acf?.data?.service_page_section_7_title}</p>
                        </div>
                        <div className="ServiceKeyChanges">
                            {pageData?.acf?.data?.service_page_section_7_card?.map(
                                (item: any, index: any) => {





                                    return (
                                        <div
                                            className="item"
                                            style={{ cursor: "pointer" }}
                                            key={index}
                                        >
                                            <div className="card-parts-1 card-parts-2">
                                                <div className="card">

                                                    <img
                                                        src={item?.image}
                                                        className="card-img-top"
                                                        alt="..."
                                                    />

                                                    <div className="card-body heading5 p-4">

                                                        <h4 className="card-title mb-2">
                                                            {item?.title}
                                                        </h4>

                                                        <p className="card-text">
                                                            {item?.description}
                                                        </p>

                                                        <div className="mt-4">
                                                            <Link
                                                                href={`/${item?.page_info}`}
                                                                className="btn btn-orange"
                                                            >
                                                                <span className="btn_label_1">
                                                                    {item?.cta?.title}
                                                                </span>

                                                                <span className="btn_icon">
                                                                    <i className="fa-solid fa-arrow-right"></i>
                                                                </span>

                                                            </Link>
                                                        </div>

                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    );
                                }
                            )}
                        </div>

                    </div>
                </div>
            </div>
            <ServiceContact />
        </main >
    );
};

export default Services;
